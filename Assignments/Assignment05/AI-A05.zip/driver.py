'''
Created on Apr 15, 2018

@author: mroch
'''

from ml_lib.example_reader import CSVDataSet
from ml_lib.learning import (DataSet, 
                             DecisionTreeLearner, NeuralNetLearner)
from std_cv import cross_validation
from random import shuffle

from copy import deepcopy
    
def learn(dataset):

    raise NotImplemented
            

    
    
def main():
    raise NotImplemented
    
if __name__ == '__main__':
    main()
