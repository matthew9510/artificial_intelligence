# Module basicsearch_lib
